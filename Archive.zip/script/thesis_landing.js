$(document).ready(function(){    
  $('#about_wrapper').parallax({imageSrc: '/assets/thesis_landing/doheney_gray.jpg'});
  
   $('#footer_img').parallax({imageSrc: '/assets/thesis_landing/downtown_LA.jpg'});
  
  $(".about_link").on('click',function(e) {
      $('html,body').animate({
      scrollTop: $("#about_wrapper").offset().top},
      'slow');
  });
  
  $("#submit_link,#submissions").on('click',function(e){
      $('html,body').animate({
          scrollTop: $("#submit_wrapper").offset().top},
          'slow');
  });
  
  $("#top_link").on('click',function(e){
      $('html,body').animate({
          scrollTop: $("#main_nav").offset().top},
          'slow');
  });
    
  $('body').mousemove(function(e){
      var amountMovedX = (e.pageX * -1 / 100);
      var amountMovedY = (e.pageY * -1 / 25 );
      $('#map_box').css('background-position', amountMovedX + 'px ' + amountMovedY + 'px');
  });

  $("body").mousemove(function( event ) {
      var coordsX = "X: " + event.pageX;
      var coordsY = "Y: " + event.pageY;
      $("#mouse_pos_top").text(coordsX);
      $("#mouse_pos_bottom").text(coordsY);
  });    
});   




