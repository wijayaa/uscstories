var map, infoWindow, positionMarker;
var boundsCircle, boundsBox, boundsWindow;
var defaultCenter = {lat: 34.02058, lng: -118.28544};


function initMap() {
   //SET-UP
    map = new google.maps.Map(document.getElementById('demo_map'), {
        center: defaultCenter,
        minZoom: 20, 
        maxZoom: 22,
        zoom: 22,
        mapTypeId: 'roadmap',
        disableDefaultUI:true,
        gestureHandling: 'cooperative',
        keyboardShortcuts: false
    }); 
    
    infoWindow = new google.maps.InfoWindow;
    
    boundsWindow = new google.maps.InfoWindow({
       content: "NOPE!",
    });
    
    positionMarker = new google.maps.Marker({
        map: map,
        animation: google.maps.Animation.DROP
    });
    
    //INIT GEOLOCATION
    if (navigator.geolocation) {
      navigator.geolocation.watchPosition(function(position) {
        var pos = {
          lat: position.coords.latitude,
          lng: position.coords.longitude
        };

        //RE-POSITION MAP
        map.setCenter(pos);
        positionMarker.setPosition(pos);     
        infoWindow.setPosition(pos);
        infoWindow.setContent('Location found.');
        infoWindow.open(map, positionMarker);
          
        //CONSTRUCTING MAP BOUNDS
        boundsCircle = new google.maps.Circle({
            strokeOpacity: 0,
            fillOpacity: 0,
            map: map,
            radius: 25,
            center: pos
        });

        var bounds = boundsCircle.getBounds();
        var boundsSW = bounds.getSouthWest();
        var boundsNE = bounds.getNorthEast();
        
        //visualizing viewable area:
        boundsBox = new google.maps.Rectangle({
            strokeColor:'deepskyblue',
            strokeWeight: 2,
            fillOpacity: 0,
            map: map,
            center: pos,
            bounds: bounds
        });
        
        //limiting viewable area:
          var allowedBounds = new google.maps.LatLngBounds(boundsSW, boundsNE);
          var lastValidCenter = map.getCenter();
          
          google.maps.event.addListener(map, 'bounds_changed',function(){
              if (allowedBounds.contains(map.getCenter())){
                  lastValidCenter = map.getCenter();
                  boundsWindow.setPosition(lastValidCenter);
                  return;
              } else {
                  map.panTo(lastValidCenter);
                  boundsWindow.open(map);
              }
          });
          

      }, function() {
        handleLocationError(true, infoWindow, map.getCenter());
      });
    } else {
      //BROWSER DOESN'T SUPPORT
      handleLocationError(false, infoWindow, map.getCenter());
    }
  }

//ERROR ALERT:
  function handleLocationError(browserHasGeolocation, infoWindow, pos) {
    infoWindow.setPosition(pos);
    infoWindow.setContent(browserHasGeolocation ?
                          'Error: The Geolocation service failed.' :
                          'Error: Your browser doesn\'t support geolocation.');
    infoWindow.open(map);
  }

