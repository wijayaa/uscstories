function initMap() {
        var campus = {lat: 34.02051, lng: -118.28541};
        var map_options = {
            zoom: 18,
            center: {lat: 34.02119, lng: -118.28543},
            mapTypeId: 'satellite'
        }
        var infowindow = new google.maps.InfoWindow({
            content: "Drag me!"
        });

        var map = new google.maps.Map(document.getElementById('map'), map_options);
    
        var marker = new google.maps.Marker({
            position: campus,
            map: map,
            draggable: true,
            title:"drag me!"
        });
    
        google.maps.event.addListenerOnce(map, 'tilesloaded',function(){
            infowindow.open(map, marker);
        })
 
        google.maps.event.addListener(marker, 'dragend', function(ev){
            var lat = (marker.getPosition().lat()).toFixed(5);
            var lng = (marker.getPosition().lng()).toFixed(5);
        
            document.getElementById('lat_span').innerHTML = " " + lat + " ";
            document.getElementById('lng_span').innerHTML = " " + lng + " ";
        });
    

}

$(document).ready(function(){
    $('#close_info').on('click',function(){
        $('#explainer').slideToggle('slow');
        $('#mini_explainer').slideToggle('slow');
    })
    
    $('#show_info').on('click',function(){  $('#mini_explainer').slideToggle('slow');  $('#explainer').slideToggle('slow');
    })
})