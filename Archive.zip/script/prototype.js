//JQuery
 $(document).ready(function(){
     $('#greeting_box_inner').fadeIn();
     $('#close').click(function(){
         $('#greeting_box_inner').fadeOut();
     })
     
 });
 
 //Map API
 var map, infoWindow, locationWindow, circle;
 var default_center = {lat: 34.02384, lng: -118.28741};         
 
function initMap() {
     map = new google.maps.Map(document.getElementById('map'), {
         center: default_center,
         zoom: 20,
         mapTypeId:'satellite',
         disableDefaultUI: true
     });
     
     var marker = new google.maps.Marker({
         map: map,
         animation: google.maps.Animation.DROP
     });
                     
     locationWindow = new google.maps.InfoWindow;
     
     //Try Geolocation
     if (navigator.geolocation) {
         navigator.geolocation.getCurrentPosition(
             function(position) { //Callback function
                 var pos = {
                     lat: position.coords.latitude,
                     lng: position.coords.longitude
                 };
                                 
                 //Reposition map and drop geolocation pin.
                 marker.setMap(map)
                 marker.setPosition(pos);
                 map.setCenter(pos);
                 
                 //Location Window information
                //make Geolocation coords accessible as String
                var userLat = position.coords.latitude;
                var userLng = position.coords.longitude;
                 
                 locationWindow.setContent("You are located at " + userLat.toFixed(4) + ", " + userLng.toFixed(4));

                 circle = new google.maps.Circle({
                     map: map,
                     strokeColor: 'white',
                     strokeOpacity: 0.8,
                     strokeWeight: 2,
                     fillColor: 'white',
                     fillOpacity: 0.25,
                     radius: 50,
                     center: {lat: userLat, lng: userLng}
                 });  

                 marker.addListener('click', function(){
                     locationWindow.open(map, marker);
                 });

            }, function() {
                handleLocationError(true, infoWindow, map.getCenter());
            });
         
     } else { 
         // Browser doesn't support Geolocation
         handleLocationError(false, infoWindow, map.getCenter());
     }
    
    map.fitBounds(circle.getBounds());
 }

 function handleLocationError(browserHasGeolocation, infoWindow, pos) {
   infoWindow.setPosition(pos);
   infoWindow.setContent(browserHasGeolocation ?
                         'Error: The Geolocation service failed; Default center used' :
                         'Error: Your browser doesn\'t support geolocation.');
   infoWindow.open(map);
 }
 

