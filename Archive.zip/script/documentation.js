//THIS IS THE SCRIPT FILE FOR DOCUMENTATION

//JQuery
 $(document).ready(function(){
     $('#greeting_box_inner').fadeIn();
     $('#close').click(function(){
         $('#greeting_box_inner').fadeOut();
     })
 });
 
 //Map API - Geolocation
var geoMap, infoWindow, geoWindow, geoMarker;
var boundsMap, boundsCircle, boundsWindow, boundsMarker, boundsBox;  
var default_center = {lat: 34.02384, lng: -118.28741};         
 
function initMap() {
    
    ////SET UP////
    //geolocation module
     geoMap = new google.maps.Map(document.getElementById('geo_map'), {
         center: default_center,
         zoom: 20,
         mapTypeId:'satellite',
         disableDefaultUI: true,
         gestureHandling: 'cooperative',
         keyboardShortcuts: false,
         draggable: false
     });
 
    geoMarker = new google.maps.Marker({
         map: geoMap,
         animation: google.maps.Animation.DROP
     });
         
    geoWindow = new google.maps.InfoWindow;
     
    //bounds module
    boundsMap = new google.maps.Map(document.getElementById('bounds_map'),{
       center: default_center,
        minZoom: 20, 
        maxZoom: 20,
        zoom: 20,
        mapTypeId: 'satellite',
        disableDefaultUI:true,
        gestureHandling: 'cooperative',
        keyboardShortcuts: false
    });
    
    boundsMarker = new google.maps.Marker({
        map: boundsMap,
        animation: google.maps.Animation.DROP
    });
    
    boundsWindow = new google.maps.InfoWindow;

    ////INIT GEOLOCATION////
     if (navigator.geolocation) {
         navigator.geolocation.getCurrentPosition(
             function(position) {
                 var pos = {
                     lat: position.coords.latitude,
                     lng: position.coords.longitude
                 };
                                 
                 //Reposition map and drop geolocation pin.
                 geoMarker.setMap(geoMap)
                 geoMarker.setPosition(pos);
                 geoMap.setCenter(pos);
                 
    //DISPLAYING GEOLOCATION CO-ORDS
                var userLat = position.coords.latitude;
                var userLng = position.coords.longitude;
                 
                 geoWindow.setContent("You are located at " + userLat.toFixed(4) + ", " + userLng.toFixed(4)); 

                 geoMarker.addListener('click', function(){
                     geoWindow.open(geoMap, geoMarker);
                 });
                 
    //LIMITING BOUNDS
                boundsMap.setCenter(pos);
                 
                boundsMarker.setPosition(pos)
                boundsCircle = new google.maps.Circle({
                    strokeColor: 'white',
                    strokeWeight: 4,
                    fillColor: 'white',
                    fillOpacity: 0.05,
                    radius: 50,
                    map: boundsMap,
                    center: pos
                 });
                 
                 var bounds = boundsCircle.getBounds();
                 var boundsSW = bounds.getSouthWest();
                 var boundsNE = bounds.getNorthEast();
                 
                 boundsBox = new google.maps.Rectangle({
                    strokeColor: 'deepskyblue',
                    strokeWeight: 4,
                    fillColor: 'white',
                    fillOpacity: 0.05,
                    map: boundsMap,
                    center: pos,
                    bounds: bounds
                 })
                 
                 var allowedBounds = new google.maps.LatLngBounds(boundsSW, boundsNE);
            
                 var lastValidCenter = boundsMap.getCenter();
                      
                 google.maps.event.addListener(boundsMap, 'bounds_changed',function(){
                     if (allowedBounds.contains(boundsMap.getCenter())) {
                         //still within valid bounds, update last known position
                        lastValidCenter = boundsMap.getCenter();
                            
                         boundsMarker.setPosition(lastValidCenter); 
                         document.getElementById('last_valid').innerHTML = /*boundsSW + " " + boundsNE*/ lastValidCenter
                         return;
                     } else {
                         //return map to the last valid center
                         boundsMap.panTo(lastValidCenter);
                     }
                 });
                 
            }, function() {
                handleLocationError(true, infoWindow, geoMap.getCenter());
            });
     } else { 
         // Browser doesn't support Geolocation
         handleLocationError(false, infoWindow, geoMap.getCenter());
     }
 }

 function handleLocationError(browserHasGeolocation, infoWindow, pos) {
   infoWindow.setPosition(pos);
   infoWindow.setContent(browserHasGeolocation ?
                         'Error: The Geolocation service failed; Default center used' :
                         'Error: Your browser doesn\'t support geolocation.');
   infoWindow.open(geoMap);
 };
 

